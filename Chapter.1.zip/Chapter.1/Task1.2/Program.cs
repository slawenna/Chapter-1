﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task1._2
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("System.Console class represents the standard input, output, " +

                "and error streams for console applications. This class cannot be inherited.");
        }
    }
}
