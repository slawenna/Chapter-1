﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task1._13
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("ther popular programming languages are C++, Delphi, Java, Python, HTML." +

                  "The difference between them is in the syntax of code writing.");
        }
    }
}
