﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task1._3
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Console.Writeline method writes the specified data, followed" +

                   " by the current line terminator, to the standard output stream.");
        }
    }
}
