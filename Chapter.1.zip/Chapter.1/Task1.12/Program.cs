﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task1._12
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(" C# is a general object-oriented programming (OOP) language for networking and Web development. " +

                "C# is specified as a common language infrastructure (CLI) language. .NET Framework is a software framework developed " +

                "by Microsoft that runs primarily on Microsoft Windows. It includes a large class library named Framework Class Library (FCL) " +

                "and provides language interoperability across severalprogramming languages. Programs written for .NET Framework execute " +

                "in a software named Common Language Runtime(CLR), an application virtual machine that provides services such as security, " +

                "memory management, and exception handling.");
        }
    }
}
