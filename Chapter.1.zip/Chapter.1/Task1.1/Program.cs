﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task1._1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("I am familiar with Microsoft Visual Studio and Microsoft Developer Network (MSDN) Library Documentation and I have already installed Visual Studio.");
        }
    }
}
